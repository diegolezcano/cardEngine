--Josefina - The Vampire
--A normal monster.
local s,id=GetID()
function s.initial_effect(c)
	--Normal monster, no special effects needed
end

