-- Normal Monster Template
-- Card ID: 10000104
-- Card Name: Mystery
-- This is a normal monster with no effects

function c10000104.initial_effect(c)
	-- Normal monsters don't have effects, so this function can be empty
	-- or you can add auxiliary effects here if needed
end

