-- Normal Monster Template
-- Card ID: 10000101
-- Card Name: Jinu
-- This is a normal monster with no effects

function c10000101.initial_effect(c)
	-- Normal monsters don't have effects, so this function can be empty
	-- or you can add auxiliary effects here if needed
end

